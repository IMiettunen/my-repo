"""
COMP.CS.100 Ohjelmointi 1
Ilari Miettunen
Ilari.miettunen@tuni.fi
opiskelijanumero: 050371213
RULETTI.
Rulettia mukaileva peli, jossa pelaaja valitsee itselleen numeroita väliltä
0-36 pilkulla eroteltuna TAI värin (musta/punainen) ja pyörittää rulettipyörää.
Pelaaja voi joko pelata ilman panosta tai lisätä rahaa lompakkoon ja valita
rahatilanteeseensa sopivan panoksen. Panos jaetaan tasan valittujen numeroiden
kesken, jos useampia. Ohjelma ilmoittaa jos kyseessä on
nollapanos pyöräytys ja antaa varoituksen jos pelaaja yrittää valita
negatiivisa numeroita, jotain muita numeroita tai merkkejä kuin
kokonaisnumeroita tai jos panos on suurempi kuin mihin pelaajalla on varaa.
Pyöräytyksen taustalla on tunnelmaa luomassa rulettipyörän ääni.
"?"- nappulasta aukeaa peliohjeet ja löytyy infoa voitonmaksusta. Muut nappulat
menevät disabled-tilaan kun pelaaja pyöräyttää pyörää. Alkuperäinen ajatus oli
tavoitella alkeellista työtä, mutta ideoiden kasvaessa tarkoitus oli tehdä
kehittynyt versio.
"""
from tkinter import *
import random  # arvontaa varten
import time  # animaation ajastusta varten
from tkinter import simpledialog  # rahamäärän syöteikkunaa varten
import math  # voittosuman laskuja varten
import winsound  # äänen toistamista varten


class Roulette:
    def __init__(self):
        # Luodaan halutunlainen pääikkuna
        self.__mw = Tk()
        self.__mw.geometry("400x200+500+200")
        self.__mw.title("ROULETTE")
        self.__mw.option_add("*Font", "Helvetica 10")
        # Estää pelaajaa muuttamasta ikkunan kokoa koska upea taustakuva
        # ei veny mukana.
        self.__mw.resizable(width=False, height=False)

        # Lisätään rulettikuvat listaan niiden arvoa vastaavien indeksien
        # paikalle.
        self.__images = []
        for i in range(0, 41):
            new_image = PhotoImage(file=f"{i}.PNG")
            self.__images.append(new_image)

        # Luodaan pääikkunalle upea tausta.
        background_label = Label(self.__mw, image=self.__images[40])
        background_label.place(x=0, y=0, relwidth=1, relheight=1)

        # Luodaan rahan lisäys nappula ja lompakko label ja sijoitetaan ne
        # pääikkunaan
        add_money_button = Button(self.__mw, text="Add money €", font='Bold',
                                  bg='yellow', relief=GROOVE,
                                  command=self.add_money)
        add_money_button.grid(row=2, column=0, columnspan=4, sticky=W + E)
        self.__wallet = Label(self.__mw, text=0.0, bg='grey')
        self.__wallet.grid(row=3, column=1, columnspan=2, sticky=W + E)

        # Luodaan otsikko ja panoksen näyttämis labelit ja '+-' nappulat
        # panoksen käsittelyä varten ja sijoitetaan ikkunaan.
        bet_label = Label(self.__mw, text="Place a bet", font='Bold',
                          bg='yellow', relief=GROOVE)
        bet_label.grid(row=2, column=10, columnspan=4, sticky=W + E)
        self.__your_bet = Label(self.__mw, text=0.0, bg='grey')
        self.__your_bet.grid(row=3, column=10, columnspan=2, sticky=W + E)
        # Panoksen lisäys ja vähennys painikkeet johtavat samaan metodiin,
        # mutta eri lähtöarvoilla, minkä johdosta metodi tietää mistä tultiin
        self.__bet_less = Button(self.__mw, text="-", bg='green',
                                 relief=GROOVE,
                                 command=lambda: self.place_bet(0))
        self.__bet_less.grid(row=3, column=12, sticky=W + E)
        self.__bet_more = Button(self.__mw, text="+", bg='green',
                                 relief=GROOVE,
                                 command=lambda: self.place_bet(1))
        self.__bet_more.grid(row=3, column=13, sticky=W + E)

        # Seuraavaksi värin valintaan liittyvät otsikko ja painikkeet.
        pick_color = Label(self.__mw, text="Pick a color", bg='green',
                           borderwidth=3, relief=RAISED)
        pick_color.grid(row=5, column=0, columnspan=4, sticky=W + E)
        # Valintapainikkeet toimivat kuten + ja - edellä. Johtavat kesksenään
        # samaan metodiin eri lähtöarvoilla, mistä tietää kumman värin pelaaja
        # valitsi.
        self.__black_button = Button(self.__mw, image=self.__images[38],
                                     bg='grey', borderwidth=2, relief=RAISED,
                                     command=lambda: self.color(2))
        self.__black_button.grid(row=7, column=0, columnspan=2, sticky=W + E)
        self.__red_button = Button(self.__mw, image=self.__images[37],
                                   bg='grey', borderwidth=2, relief=RAISED,
                                   command=lambda: self.color(1))
        self.__red_button.grid(row=7, column=2, columnspan=2, sticky=W + E)

        # Alustaa rulettipyöräanimaation paikalle kuvan rulettipyörästä.
        self.__roulette_wheel = Label(self.__mw, image=self.__images[39],
                                      relief=GROOVE, borderwidth=0)
        self.__roulette_wheel.grid(row=7, column=7, columnspan=2)

        # Numeroiden valintaan liittyvät otsikko ja syötekenttä.
        pick_number = Label(self.__mw,
                            text="Pick number(s) between 0-36",
                            bg='green', borderwidth=3, relief=RAISED)
        pick_number.grid(row=5, column=10, columnspan=4, sticky=W + E)
        self.__number_pick = Entry(width=16, bg='grey')
        self.__number_pick.grid(row=6, column=10, columnspan=4)

        # Painike ruletin pyörittämiseen, jos pelaaja haluaa pelata numeroilla.
        self.__spin_button = Button(self.__mw, text="Spin the wheel",
                                    bg='black', fg='white', borderwidth=3,
                                    relief=RAISED, command=self.spin)
        self.__spin_button.grid(row=7, column=10, columnspan=4, rowspan=2,
                                sticky=W + E + N + S)

        # Painike pelaamisen lopettamiseen. Sulkee pääikkunan ja ohjelman.
        self.__quit_button = Button(self.__mw, text="Quit", command=self.quit,
                                    bg='black', fg='white')
        self.__quit_button.grid(row=9, column=13, columnspan=2, sticky=W + E)

        # Painike, josta pelaaja voi avata ohjeet pelin pelaamiseen ja voiton-
        # maksuun. Avaa ohjetiedoston uudessa ikkunassa.
        self.__help_button = Button(self.__mw, text="?", bg='black',
                                    fg='white', command=self.help)
        self.__help_button.grid(row=9, column=12, sticky=W + E)

        # Tulos/ohje/viesti-ikkuna johon tulostuu virheilmoitukset, ohjeet ja
        # onnentoivotukset.
        self.__result_window = Label(self.__mw, bg='black', fg='white')
        self.__result_window.grid(row=9, column=0, columnspan=6, sticky=W + E)

        self.__mw.mainloop()

    def spin(self):
        """
        Performs draw if player chose to play with number(s).
        :return:
        """
        # Hankkii pelaajan syöttämät numerot ja luo niistä listan.
        number_entry = self.__number_pick.get()
        chosen_numbers = list(number_entry.split(","))

        # Tarkistetaan, onko pelaajan syöte käyttökelpoista
        for value in chosen_numbers:
            # Onko se/ne kokonaislukuja
            try:
                int(value)
            except ValueError:
                # Jos ei niin virheilmoitus ja syötekentän nollaus.
                self.__result_window['text'] = "Must be integer(s)!"
                self.reset_fields()
                return
            # Hyväksyy vain nollan ja suuremmat numerot.
            if int(value) < 0:
                self.__result_window['text'] = "Only positive numbers!"
                self.reset_fields()
                return
            # Ei hyväksy arvoja 0-36 ulkopuolelta
            if int(value) > 36:
                self.__result_window['text'] = "Numbers from 0 to 36!"
                self.reset_fields()
                return

        # Deaktivoi painikkeet ja jättää pohjaan painetun 'spin' painikkeen
        self.__quit_button.config(state=DISABLED)
        self.__black_button.config(state=DISABLED)
        self.__red_button.config(state=DISABLED)
        self.__spin_button.config(relief=SUNKEN, state=DISABLED)
        self.__help_button.config(state=DISABLED)

        # Arpoo voittavan numeron ja alustaa result muuttujan Falseksi.
        arvottu = random.randint(0, 36)
        result = False
        bet = self.__your_bet['text']

        # Jos kate riittää, pyöritetään animaatio.
        if self.balance(bet):
            self.spin_animation(arvottu)
            # Jos arvottu numero löytyy pelaajan syötelistasta result=True
            for i in chosen_numbers:
                if int(i) == arvottu:
                    result = True
            # Jos result = True..
            if result:
                # Lasketaan voiton määrä, tulostetaan tieto siitä ja lisätään
                # palkinto lompakkoon. Muussa tapauksessa tulostetaan huonot
                # uutiset.
                prize = winnings(chosen_numbers, bet)
                self.__result_window['text'] = f"You Won {prize}€!"
                self.__wallet['text'] += prize
            else:
                self.__result_window['text'] = "You Lost"

        # Palautetaan painikkeet normaalitilaan.
        self.__spin_button.config(relief=RAISED, state=NORMAL)
        self.__quit_button.config(state=NORMAL)
        self.__black_button.config(state=NORMAL)
        self.__red_button.config(state=NORMAL)
        self.__help_button.config(state=NORMAL)

    def color(self, color):
        """
        Performs the draw if player chooses to bet on either of the two colors.
        :param color:
        :return:
        """
        # Deaktivoidaan muut kuin käytetty painike.
        self.__help_button.config(state=DISABLED)
        self.__spin_button.config(state=DISABLED)
        self.__quit_button.config(state=DISABLED)
        # Nollaa numerovalintaikkunan, koska sillä ei ole käyttöä tässä kohtaa
        self.__number_pick.delete(0, 'end')
        # Jättää painetun painikkeen pohjaan. Muuttujan 'color' arvo kertoo
        # kumpaa painiketta on painettu. 2 = musta ja 1 = punainen.
        if color == 1:
            self.__red_button.config(relief=SUNKEN)
        if color == 2:
            self.__black_button.config(relief=SUNKEN)

        # Muuttujalle 'bet' saadaan arvo your_bet labelista.
        bet = self.__your_bet['text']

        # Arvotaan voittava numero 0-36
        arvottu = random.randint(0, 36)

        # Mutetaan värin arvo vertailukelpoiseen int- muotoon
        value = int(color)

        # Jos käyttövara sallii pelaamisen valitulla panoksella..
        if self.balance(bet):
            # ..animaatio pyörähtää
            self.spin_animation(arvottu)
            # Seuraavaksi tulostetaan arvonnan tulos ja lisätään mahdolliset
            # voitot lompakkoon.
            if arvottu == 0:
                self.__result_window['text'] = "You Lost"
            elif arvottu % 2 == value % 2:
                self.__result_window['text'] = f"You Won {2 * bet}€"
                self.__wallet['text'] += 2 * bet
            else:
                self.__result_window['text'] = "You Lost"
        # Palautetaan aiemmin säädetyt painikkeet takaisin normaalitilaan.
        if color == 1:
            self.__red_button.config(relief=RAISED)
        if color == 2:
            self.__black_button.config(relief=RAISED)
        self.__quit_button.config(state=NORMAL)
        self.__spin_button.config(state=NORMAL)
        self.__help_button.config(state=NORMAL)

    def add_money(self):
        """
        Adds amount of money chosen by player to player's wallet.
        :return:
        """
        # Tässä ikkunassa pelaaja syöttää haluamansa rahasumman, joka lisätään
        # lompakkoon.
        money = simpledialog.askfloat("Add money to your wallet",
                                      "Type in amount")
        # Esittää uuden summan lompakossa, ja nollaa result_window Labelin, jos
        # pelaaja on lisännyt rahaa esim 'add money' ilmoituksen jälkeen.
        self.__wallet['text'] += money
        self.__result_window['text'] = ""

    def balance(self, bet):
        """
        Keeps track of the balance. Checks if bet is bigger than amount of
        usable money.
        :return:
        """
        money = self.__wallet['text']
        # Tulostaa ilmoituksen nollapyöräytyksestä
        if bet == 0:
            self.__result_window['text'] = "Poor person spin"
            return True
        # Tulostaa ilmoituksen ja estää pelaamasta jos panos > varat.
        if money - bet < 0:
            self.__result_window['text'] = "Add money or bet less"
            return False
        # Jos kaikki on ok, vähentää panostetun summan lompakosta ja toivottaa
        # onnea.
        else:
            self.__result_window['text'] = "Good Luck!"
            self.__wallet['text'] = money - bet
            return True

    def place_bet(self, value):
        """
        Increases or decreases bet 0.5€ at a time when pressed '+' or '-'.
        Value tells which button was pressed '-' = 0 and '+' = 1.
        :return:
        """
        # Lisää tai vähentää panosta riippuen pelaajan valinnasta
        your_bet = self.__your_bet['text']
        if value == 0:
            your_bet -= 0.5
        else:
            your_bet += 0.5
        # Ei anna valita negatiivista panosta. Näyttää panokseksi siis 0.0€ tai
        # pelaajan valintaa
        if your_bet < 0:
            self.__your_bet['text'] = 0.0
        else:
            self.__your_bet['text'] = your_bet

    def spin_animation(self, arvottu):
        """
        Creates spin animation with images and sound. Changes images randomly
        with slowing rate. Ends showing number which was drawn earlier.
        """
        # Huikea rulettiääni pyörii animaation taustalla eikä keskeytä
        # ohjelman suorittamista
        winsound.PlaySound('Ruletti.wav', winsound.SND_ASYNC |
                           winsound.SND_ALIAS)
        # Valitsee 20 kertaa random numeron 0-36 ja näytää sitä vastaavan kuvan
        for i in range(0, 20):
            x = random.randint(0, 36)
            self.__roulette_wheel["image"] = self.__images[x]
            self.__mw.update_idletasks()
            time.sleep(0.09)
        # Joka toistolla vaihdeltavien kuvien määrä vähenee ja päivitysnopeus
        # hidastuu. Tämä luo vaikutelman pyörän hidastumisesta.
        for i in range(0, 10):
            x = random.randint(0, 36)
            self.__roulette_wheel["image"] = self.__images[x]
            self.__mw.update_idletasks()
            time.sleep(0.18)
        for i in range(0, 8):
            x = random.randint(0, 36)
            self.__roulette_wheel["image"] = self.__images[x]
            self.__mw.update_idletasks()
            time.sleep(0.23)
        for i in range(0, 6):
            x = random.randint(0, 36)
            self.__roulette_wheel["image"] = self.__images[x]
            self.__mw.update_idletasks()
            time.sleep(0.3)
        for i in range(0, 3):
            x = random.randint(0, 36)
            self.__roulette_wheel["image"] = self.__images[x]
            self.__mw.update_idletasks()
            time.sleep(0.42)
        # Jättää lopuksi näkyville alunperin arvotun numeron, jonka sai lähtö-
        # arvona.
        self.__roulette_wheel["image"] = self.__images[arvottu]

    def reset_fields(self):
        """
        In error situations this method will zeroize the elements
        self.__number_pick.
        """
        self.__number_pick.delete(0, END)
        pass

    def help(self):
        """
        Opens text file containing instructions to play the game. Shows
        them in new window.
        :return:
        """
        # Luodaan uusi 500x400 ikkuna otsikolla instructions ja vihreällä
        # taustalla.
        help_box = Toplevel(self.__mw)
        help_box.title("INSTRUCTIONS")
        help_box.configure(bg='green')
        help_box.geometry("500x400+600+100")
        # Avataan tekstitiedosto, luetaan se, lisätään ikkunaan ja suljetaan
        # tiedosto.
        txt_file = open(file="Instructions.txt", mode="r")
        instructions = txt_file.read()
        how_to_play = Label(help_box, text=instructions)
        how_to_play.pack()

        txt_file.close()

    def quit(self):
        """
        Ends the game and closes mainwindow.
        :return:
        """
        self.__mw.destroy()


def winnings(luckynumbers, bet):
    """
    If player wins, this function calculates the amount player will get.
    Prize is rounded to closest 0.5€. Factor for prize money is 35/(amount of
    chosen numbers) without decimals. Doesnt calculate winnings if choosing
    color.

    :param luckynumbers: list, Numbers that player wants to bet on
    :param bet: float, amount of money player wants to bet
    :return: float, amount of money player has won
    """
    # Ensin selvitetään voittokerroin ja panos per valinta.
    factor = 35 // len(luckynumbers)
    bet_per_pick = bet / len(luckynumbers)
    # Sitten todellinen voittosumma.
    real_prize = float(factor * bet_per_pick)
    # Ja voittosumma pyöristettynä ylös ja alas kokonaislukuun tarkempaa
    # pyöristystä varten.
    roundup_real_prize = math.ceil(real_prize)
    rounddown_real_prize = math.floor(real_prize)

    # Lopuksi vielä pyöristetään 0.5€ tarkkuuteen, selvittämällä tarkan voitto-
    # summan suhdetta ylös ja alas pyöristettyihin arvoihin.
    if roundup_real_prize - real_prize > 0.75:
        paid_prize = rounddown_real_prize
    elif roundup_real_prize - real_prize > 0.25:
        paid_prize = roundup_real_prize - 0.5
    else:
        paid_prize = roundup_real_prize
    return float(paid_prize)


def main():
    Roulette()


if __name__ == "__main__":
    main()
